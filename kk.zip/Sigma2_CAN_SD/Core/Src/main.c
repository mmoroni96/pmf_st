/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "app_fatfs.h"
#include "fdcan.h"
#include "usart.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Sigma2_Def.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef union{
	uint8_t		Data8u[8];
	uint16_t	Data16u[4];
	int16_t		Data16[4];
}data_typedef;

typedef enum{
	IDLE		= 0x00U,
	STARTUP		= 0X01U,
	SPIN		= 0x02U,
	STOP		= 0X03U
}Sigma2_Status;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAXTORQUE	100	// Maximum allowable torque[Nm]
#define MAXCURRENT	600 // Maximum allowable rms current[A]
#define KT			140 // Toqe constant [Nm/kArms]
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
int32_t ProcessStatus = 0;
uint8_t ubKeyNumber = 0x0;
FDCAN_RxHeaderTypeDef RxHeader;
uint8_t RxData[8];
data_typedef rxData;
data_typedef txData;
char buffer[100];
FDCAN_TxHeaderTypeDef TxHeader;
uint8_t TxData[8];
uint32_t id;
uint8_t DataSpi[8];
uint8_t readBuff[64];
uint8_t br;
int32_t curr;
uint32_t indice = 0;
uint32_t time;
uint32_t index = 0;
uint8_t flag = 0;
uint8_t Time[3];
uint8_t Date[3];
RTC_TimeTypeDef stimeststuctureget;
RTC_DateTypeDef Data;
FATFS USERFatFs;    /* File system object for USER logical drive */
struct{
	int16_t Temp_0;
	int16_t Temp_1;
	int16_t Temp_2;
	int16_t Temp_3;
	int16_t Temp_4;
	int16_t Temp_5;
	int16_t Temp_6;
	int16_t Temp_7;
	int16_t Temp_8;
	int16_t Temp_9;
}Temp;
struct{
	int16_t Acc_x;
	int16_t Acc_y;
	int16_t Acc_z;
	int16_t Gir_x;
	int16_t Gir_y;
	int16_t T_a;
	int16_t T_g;
	int16_t T_b;
	uint32_t Pres;
	uint16_t Hum;
	uint16_t Responce_Time_millis;
	uint32_t Timer;
	uint8_t ID;
}Dati;
uint32_t ID = 0x00;
int32_t torque;
uint8_t dir = 0;
uint8_t fs = 0;
uint8_t en = 0;
MS_typedef ms;
CS_typedef cs;
DS_typedef ds;
DC_typedef dc;
unsigned char motorTemp;
int32_t torque;
Sigma2_Status status;
uint8_t	controlStatus;
uint8_t	count = 0;

//uint8_t path[];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_NVIC_Init(void);
/* USER CODE BEGIN PFP */
uint32_t chartotime(uint8_t*, uint8_t, uint8_t);
int32_t chartotorque(uint8_t*, uint8_t, uint8_t);
FRESULT scrivi();
uint32_t PuntaeSepara(uint8_t*);
FRESULT leggi();
void Success_Handler(void);
void salvaDati(void);

uint8_t readSigmaData(void);
void CAN_TxData_Init(void);
void DC_TxData_Build(int32_t torque);
//void DC_Data_Build(int32_t torque);
uint8_t CAN_TxMsg(void);
uint16_t SetThrottle(int32_t torque);
void Set_Switch(uint8_t Dir, uint8_t Fs, uint8_t En, uint8_t HandBrake);
void StartUp_Sequence(void);
void Toggle_Bit(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* Initialize the micro SD Card */
  if(MY_SD_Init(0) != BSP_ERROR_NONE){
	  Error_Handler();
  }
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_SPI2_Init();
  if (MX_FATFS_Init() != APP_OK) {
    Error_Handler();
  }
  MX_FDCAN1_Init();
  MX_RTC_Init();
  MX_TIM16_Init();
  MX_TIM17_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */
  CAN_TxData_Init();

  //uint16_t aug = 3456;

    if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK){
        /* Start Error */
        Error_Handler();
    }

    if ( HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0) != HAL_OK){
        /* Notification Error */
        Error_Handler();
    }
    torque = 0;
    dir = 0; fs = 0; en = 0;
    Set_Switch(dir, fs, en, 0);
    DC_TxData_Build(torque);
    HAL_TIM_Base_Start_IT(&htim17);
    //StartUp_Sequence();
  /* USER CODE END 2 */
 
 

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1){
	  /*torque = 0;
	  CAN_TxMsg();
	  readSigmaData();*/

	  switch(status){

	  case IDLE:
		  torque = 0;
		  dir = 0; fs = 0; en = 0;
		  Set_Switch(dir, fs, en, 0);
		  DC_TxData_Build(torque);

		  if(count > 100){
			  status = STARTUP;
			  controlStatus = 1;
			  count = 0;
		  }
		  break;

	  case STARTUP:
		  torque = 0;
		  switch(controlStatus){

		  case 1:
			  // enable
			  if(count > 100){
				  en = 1;
				  Set_Switch(dir, fs, en, 0);
				  DC_TxData_Build(torque);
				  controlStatus = 2;
				  count = 0;
			  }
			  DC_TxData_Build(torque);
			  break;
		  case 2:
			  // footswitch
			  if(count > 100){
				  fs = 1;
				  Set_Switch(dir, fs, en, 0);
				  DC_TxData_Build(torque);
				  controlStatus = 3;
				  count = 0;
			  }
			  DC_TxData_Build(torque);
			  break;
		  case 3:
			  // direction
			  if(count > 100){
				  dir = 1; // forward
				  Set_Switch(dir, fs, en, 0);
				  DC_TxData_Build(torque);
				  status = SPIN;
				  count = 0;
			  }
			  DC_TxData_Build(torque);
			  break;
		  default:
			  en = 0; fs = 0; dir = 0;
			  Set_Switch(dir, fs, en, 0);
			  DC_TxData_Build(torque);
			  controlStatus = 1;
			  break;
		  }
		  break;
	  case SPIN:
		  /*for(uint8_t i=0; i<20; i++){
			  torque++;
		  }*/
		  torque = 2;
		  DC_TxData_Build(torque);
		  break;
	  case STOP:

		  break;
	  default:

		  break;
	  }

	  //CAN_TxMsg();
	  HAL_Delay(10);
	  //readSigmaData();
	  //HAL_Delay(50);
	  count++;
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage 
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Configure LSE Drive Capability 
  */
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV2;
  RCC_OscInitStruct.PLL.PLLN = 32;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV6;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the peripherals clocks 
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_LPUART1
                              |RCC_PERIPHCLK_FDCAN;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
  PeriphClkInit.FdcanClockSelection = RCC_FDCANCLKSOURCE_PCLK1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* FDCAN1_IT0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
  /* EXTI15_10_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
  /* TIM1_TRG_COM_TIM17_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_TRG_COM_TIM17_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM1_TRG_COM_TIM17_IRQn);
  /* TIM1_UP_TIM16_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);
}

/* USER CODE BEGIN 4 */

void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef*hcan, uint32_t RxFifo0ITs){
	if(HAL_FDCAN_GetRxMessage(&hfdcan1,FDCAN_RX_FIFO0,&RxHeader,rxData.Data8u) != HAL_OK){
		/* Transmission request Error */
		Error_Handler();
	}
	ID = RxHeader.Identifier;
	readSigmaData();
    /*if(flag == 1){
    	salvaDati();
    }*/

	//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance==TIM17){ //check if the interrupt comes from TIM2 (occur every 100mS)

    	CAN_TxMsg();

    }
    /*if (htim->Instance==TIM17) //check if the interrupt comes from TIM2
            {
        	//HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        	// TO DO: perchè scrivi() viene chiamato qui?
        	//uint8_t path[] = "STM32.TXT";
        	//uint8_t path1[] = "COPPIA.TXT";

        	//leggi();
			//CAN_TxMsg();
        	//scrivi();
        	if(HAL_GPIO_ReadPin(B1_GPIO_Port,B1_Pin)==GPIO_PIN_SET)
        	{
        		HAL_Delay(10000);
        	}
     }*/
}

uint8_t readSigmaData(void){
	uint8_t res;
	res = HAL_FDCAN_GetRxMessage(&hfdcan1,FDCAN_RX_FIFO0,&RxHeader,rxData.Data8u);

	switch(RxHeader.Identifier){
	case MS:
			ms.MotorSpeed			= rxData.Data16u[0];
			ms.MotorCurrent			= rxData.Data16[1];
			ms.MotorVoltage			= rxData.Data8u[4];
			ms.BatteryVoltage		= rxData.Data8u[5];
			ms.BatteryCurrent		= rxData.Data16[4];
	break;
	case DS:
			ds.ActualTorque			= rxData.Data16[0];
			ds.ActualSpeed			= rxData.Data16[1];
			ds.DriveStatusIndicator	= rxData.Data8u[4] & 0x0F;
			ds.SpeedLimitIndicator	= rxData.Data8u[4] >> 0x04;
			ds.TorqueLimitIndicator	= rxData.Data8u[5] & 0x0F;
			ds.MotorLimitIndicator	= rxData.Data8u[5] >> 0x04;
			ds.FaultCode			= rxData.Data8u[6];
			ds.Code					= rxData.Data8u[7];
	break;
	case CS:
			cs.ControllerTemperature= rxData.Data8u[0];
			cs.MotorTemperature		= rxData.Data8u[1];
			cs.BDI					= rxData.Data8u[2];
			cs.FaultSubCode			= rxData.Data8u[3] << 0x08 | rxData.Data8u[4];
	break;
	}
	return res;
}

/*void DC_Data_Build(int32_t torque){
	dc.Trottle = SetThrottle(torque);
}*/

void Set_Switch(uint8_t Dir, uint8_t Fs, uint8_t En, uint8_t HandBrake){
	// Dir = 1 Forward, Dir = 0 Reverse
	if(Dir > 0){
		dc.DigitalInputs = dc.DigitalInputs | 0x01<<FD;			// Set Forward Direction
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<RD);		// Reset Reverse Direction
	}
	else if(Dir < 0){
		dc.DigitalInputs = dc.DigitalInputs | 0x01<<RD;			// Set Reverse Direction
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<FD);		// Reset Forward Direction
	}
	else{
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<FD);		// Reset Forward Direction
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<RD);		// Reset Reverse Direction
	}

	if(Fs > 0){
		dc.DigitalInputs = dc.DigitalInputs | 0x01<<FS;			// Set Foot Switch
	}
	else{
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<FS);		// Reset Foot Switch
	}

	if(En > 0){
		dc.DigitalInputs = dc.DigitalInputs | 0x01<<EN;			// Set Enable
	}
	else{
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<EN);		// Reset Enable
	}

	if(HandBrake > 0){
		dc.DigitalInputs = dc.DigitalInputs | 0x01<<HB;			// Set Hand Brake
	}
	else{
		dc.DigitalInputs = dc.DigitalInputs & ~(0x01<<HB);		// Reset Hand Brake
	}
}

void Toggle_Bit(){
	if(txData.Data8u[7]){
		//dc.ToggleSecurityBit = 0x00;
		txData.Data8u[7] = 0x00;
	}
	else{
		//dc.ToggleSecurityBit = 0x01;
		txData.Data8u[7] = 0x01;
	}
}

void DC_TxData_Build(int32_t torque){
  TxHeader.Identifier = DC;

  dc.Trottle = SetThrottle(torque);

  txData.Data16u[0] = dc.Trottle;
  txData.Data16u[1] = dc.BrakePedal;
  txData.Data16[2] = dc.AD3;
  txData.Data8u[6] = dc.DigitalInputs;
  //txData.Data8u[7] = dc.ToggleSecurityBit;
}

void StartUp_Sequence(void){
	en = 1;
	Set_Switch(dir, fs, en, 0);
	if (CAN_TxMsg() != HAL_OK){
	  // Transmission request Error
	  Error_Handler();
	}
	HAL_Delay(10);
	//readSigmaData();
	HAL_Delay(10);
	dir = 1;
	Set_Switch(dir, fs, en, 0);
	if (CAN_TxMsg() != HAL_OK){
	  // Transmission request Error
	  Error_Handler();
	}
	HAL_Delay(10);
	//readSigmaData();
	HAL_Delay(10);
	fs = 1;
	Set_Switch(dir, fs, en, 0);
	if (CAN_TxMsg() != HAL_OK){
	  // Transmission request Error
	  Error_Handler();
	}
	HAL_Delay(10);
	//readSigmaData();
	HAL_Delay(10);
}

uint8_t CAN_TxMsg(void){
	uint8_t res;
	Toggle_Bit();
	//DC_TxData_Build(torque);
	res = HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, txData.Data8u);

	return res;
}

// torque [Nm] -> thottle [%/4096]
uint16_t SetThrottle(int32_t torque){
	uint16_t throttle;
	// throttle is expressed in % of the maximum torque limit coded in 16bit
	throttle = torque * 4096 * 1000 / (MAXCURRENT * KT);
	return throttle;
}

void Success_Handler(void)
{
  //printf("** Success. ** \n\r");
  while(1)
  {
  }
}
uint32_t chartotime(uint8_t* buff,uint8_t off, uint8_t leng ){
	char str[8];
	for(int i=off;i<leng+off;i++){
    str[i] = buff[i];
	}
	return (uint32_t)atoi(str);
}

int32_t chartotorque(uint8_t* buff,uint8_t off, uint8_t leng ){
	char str[8];
	for(int i=0;i<leng;i++){
    str[i] = buff[i+off];
	}
	return (int32_t)atoi(str);
}

uint32_t PuntaeSepara(uint8_t* buff){
	uint8_t h;
	uint8_t e;
	for(h=0;h<64;h++){
		if(readBuff[h]==','){
			time = chartotime(readBuff,0,h);
			break;
		}
	}
	for(e=h;e<64;e++){
		//if(readBuff[e]==0xd&&readBuff[e+1]==0xa)
		if(readBuff[e]==0x0A){ // Quando termina riga salva la prima e la seconda colonna
			torque = chartotorque(readBuff,h+1,e-h);// / 1000;
			break;
		}
	}
	return (uint32_t)(e+2);//aggiungo i due caratteri di terminazione
}

FRESULT leggi(void){
	FRESULT res;
	FIL readFile;       /* File  object for USER */
	uint8_t path[] = "COPPIA.TXT";
	res = f_open(&readFile, &path, FA_READ);
	if(res == FR_OK){
		f_lseek(&readFile, indice);
		res = f_read(&readFile,readBuff, 34, &br);
		indice = indice + PuntaeSepara(readBuff);
		res = f_close(&readFile);
	}
	return res;

}

void salvaDati(void){
	motorTemp = cs.MotorTemperature - 50;

}

// TO DO: passare il percorso file ed eventualmente altro alla funzione
FRESULT scrivi(void){
	FRESULT res;
	FIL writeFile;       /* File  object for USER */
	uint8_t path[] = "STM32.TXT";
	res = f_open(&writeFile, &path, FA_WRITE | FA_OPEN_ALWAYS);
	if(res==FR_OK) {
		f_lseek(&writeFile, index);
		// TO DO: capire cosa fanno e se si possono spostare
		HAL_RTC_GetTime(&hrtc, &stimeststuctureget, RTC_FORMAT_BIN);
		HAL_RTC_GetDate(&hrtc, &Data, RTC_FORMAT_BIN);
		Time[0] = stimeststuctureget.Hours;
		Time[1] = stimeststuctureget.Minutes;
		Time[2] = stimeststuctureget.Seconds;
		// DO: modificati i dati scritti (cs.MotorTemperature)
		index = index + f_printf(&writeFile,"%d:%d:%d,%d,%d\n",Time[0],Time[1],Time[2],torque,motorTemp);
	}
		res = f_close(&writeFile);

	return res;
}

void CAN_TxData_Init(void){
  TxHeader.Identifier = 0x0;
  TxHeader.IdType = FDCAN_STANDARD_ID;
  TxHeader.TxFrameType = FDCAN_DATA_FRAME;
  TxHeader.DataLength = FDCAN_DLC_BYTES_8;
  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
  TxHeader.BitRateSwitch = FDCAN_BRS_OFF;
  TxHeader.FDFormat = FDCAN_CLASSIC_CAN;
  TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
  TxHeader.MessageMarker = 0;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	//printf("** Error. ** \n\r");
	while(1)
	{
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
