/*
 * SpeedCtrl.h
 *
 *  Created on: Mar 6, 2019
 *      Author: mic
 */

#ifndef CTRLSPEED_H_
#define CTRLSPEED_H_

#include "main.h"

void CtrlSpeed(struct SpeedStruct *,struct ControllerStruct *, const double dt);


#endif /* CTRLSPEED_H_ */
